Controls:
--------------
A = Shoot (hold to charge)
Z = Jump
Left and Right = Move
Enter = Pause
F2 = Reset
Esc = Exit

Known Bugs:
-------------------
*When fighting Storm Eagle, if you step in the bottem left corner, the battle will restart.
 